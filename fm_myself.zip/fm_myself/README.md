libFM
=====

Library for factorization machines

web: http://www.libfm.org/

forum: https://groups.google.com/forum/#!forum/libfm

Factorization machines (FM) are a generic approach that allows to mimic most factorization models by feature engineering. This way, factorization machines combine the generality of feature engineering with the superiority of factorization models in estimating interactions between categorical variables of large domain. libFM is a software implementation for factorization machines that features stochastic gradient descent (SGD) and alternating least squares (ALS) optimization as well as Bayesian inference using Markov Chain Monte Carlo (MCMC).

Compile
=======
libFM has been tested with the GNU compiler collection and GNU make. libFM and the tools can be compiled with
> make all

Usage
train
./libFM -task r -train ml1m-train.libfm -test ml1m-test.libfm -dim ’1,1,8’

./libFM -task r -train ml1m-train.libfm -test ml1m-test.libfm -dim ’1,1,8’ -weight1 0.5 -weight2 0.5  -iter 1000 -method sgd -learn_rate 0.01 -regular ’0,0,0.01’ -init_stdev 0.1
